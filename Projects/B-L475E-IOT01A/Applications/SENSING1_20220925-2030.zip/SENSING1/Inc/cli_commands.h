#ifndef __CLI_COMMANDS_H
#define __CLI_COMMANDS_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS_CLI.h"

 /* Exported functions ------------------------------------------------------ */
extern void RegisterCLICommands(void);

#ifdef __cplusplus
}
#endif

#endif /* __CLI_COMMANDS_H */