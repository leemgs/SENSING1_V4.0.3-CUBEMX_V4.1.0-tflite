/**
 ******************************************************************************
 * @file bluenrg_conf.h
 * @author   CL
  * @version V4.0.0
  * @date    30-Oct-2019
 * @brief 
 ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2018 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
 ******************************************************************************
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BLUENRG_CONF_H
#define __BLUENRG_CONF_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#include "stm32l4xx_hal.h"
#include <string.h>

//#ifndef SENSING1_BlueNRG2
//  #include "bluenrg_utils.h"
//#endif /* SENSING1_BlueNRG2 */

/*---------- Print messages from files at user level -----------*/
#define DEBUG      0
/*---------- Print the data travelling over the SPI in the .csv format for the GUI -----------*/
#define PRINT_CSV_FORMAT      0
/*---------- Number of Bytes reserved for HCI Read Packet -----------*/
#define HCI_READ_PACKET_SIZE      128
/*---------- Number of Bytes reserved for HCI Max Payload -----------*/
#define HCI_MAX_PAYLOAD_SIZE      128

#ifndef SENSING1_BlueNRG2
  /*---------- Scan Interval: time interval from when the Controller started its last scan until it begins the subsequent scan (for a number N, Time = N x 0.625 msec) -----------*/
  #define SCAN_P      16384
  /*---------- Scan Window: amount of time for the duration of the LE scan (for a number N, Time = N x 0.625 msec) -----------*/
  #define SCAN_L      16384
  /*---------- Supervision Timeout for the LE Link (for a number N, Time = N x 10 msec) -----------*/
  #define SUPERV_TIMEOUT      60
  /*---------- Minimum Connection Period (for a number N, Time = N x 1.25 msec) -----------*/
  #define CONN_P1      40
  /*---------- Maximum Connection Period (for a number N, Time = N x 1.25 msec) -----------*/
  #define CONN_P2      40
  /*---------- Minimum Connection Length (for a number N, Time = N x 0.625 msec) -----------*/
  #define CONN_L1      2000
  /*---------- Maximum Connection Length (for a number N, Time = N x 0.625 msec) -----------*/
  #define CONN_L2      2000
  /*---------- Advertising Type -----------*/
  #define ADV_DATA_TYPE      ADV_IND
  /*---------- Minimum Advertising Interval (for a number N, Time = N x 0.625 msec) -----------*/
  #define ADV_INTERV_MIN      2048
  /*---------- Maximum Advertising Interval (for a number N, Time = N x 0.625 msec) -----------*/
  #define ADV_INTERV_MAX      4096
  /*---------- Minimum Connection Event Interval (for a number N, Time = N x 1.25 msec) -----------*/
  #define L2CAP_INTERV_MIN      9
  /*---------- Maximum Connection Event Interval (for a number N, Time = N x 1.25 msec) -----------*/
  #define L2CAP_INTERV_MAX      20
  /*---------- Timeout Multiplier (for a number N, Time = N x 10 msec) -----------*/
  #define L2CAP_TIMEOUT_MULTIPLIER      600
#endif /* SENSING1_BlueNRG2 */

#define HCI_DEFAULT_TIMEOUT_MS        1000

#define BLUENRG_memcpy                memcpy
#define BLUENRG_memset                memset
#define BLUENRG_memcmp                memcmp
  
#ifndef SENSING1_BlueNRG2
  #if (DEBUG == 1)
    #define PRINTF(...)                   printf(__VA_ARGS__)
  #else
    #define PRINTF(...)
  #endif
#else /* SENSING1_BlueNRG2 */
  #if (DEBUG == 1)
    #include <stdio.h>
    #define PRINT_DBG(...)                printf(__VA_ARGS__)
  #else
    #define PRINT_DBG(...)
  #endif 
#endif /* SENSING1_BlueNRG2 */

#if PRINT_CSV_FORMAT
#include <stdio.h>
#define PRINT_CSV(...)                printf(__VA_ARGS__)
void print_csv_time(void);
#else
#define PRINT_CSV(...)
#endif

#ifdef __cplusplus
}
#endif
#endif /*__BLUENRG_CONF_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
